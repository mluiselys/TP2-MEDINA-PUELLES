#pragma once
#include <string>
#include <iostream>
class cArticulo;
using namespace std;

	extern cArticulo** Lista_articulos;
	void Llenar_articulos();
	void Eliminar_Articulos();
	void imprimir();


